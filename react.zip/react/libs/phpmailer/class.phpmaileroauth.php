<br />
<b>Fatal error</b>:  Class 'PHPMailer' not found in <b>/home/pimmey57/public_html/react/libs/phpmailer/class.phpmaileroauth.php</b> on line <b>27</b><br />
