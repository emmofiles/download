<br />
<b>Parse error</b>:  syntax error, unexpected '[', expecting ')' in <b>/home/pimmey57/public_html/react/libs/phpmailer/class.phpmaileroauthgoogle.php</b> on line <b>53</b><br />
