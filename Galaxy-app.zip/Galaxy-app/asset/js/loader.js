/**
 * modalEffects.js v1.0.0
 * http://www.galaxy-theme.com
 *
 * Copyright 2013, galaxy theme
 * http://www.galaxy-theme.com
 */

//LOADER
	$( window ).load(function() {
		$('.gloader').fadeOut('normal');
	});


