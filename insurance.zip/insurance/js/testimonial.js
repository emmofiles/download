$(document).ready(function() {
 "use strict";
  $("#testimonial").owlCarousel({
 	autoPlay: 3000, //Set AutoPlay to 3 seconds
	items : 2,
    itemsDesktop : [1199,3],
    itemsDesktopSmall : [979,3],
    navigation : false
});
});