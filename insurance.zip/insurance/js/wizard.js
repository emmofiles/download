$(document).ready(function() {
	"use strict";
  	$('#rootwizard').bootstrapWizard({'tabClass': 'nav nav-pills'});
});