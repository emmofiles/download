


/* Theme Name: Hiric - Responsive Landing page template
   Author: Themesbrand
   Version: 1.0.0
   File Description: Text Rotate JS file
*/

$(".text-rotate").textrotator({
    animation: "fade",
    speed: 1500
});