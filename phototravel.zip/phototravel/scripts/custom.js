$(window).load(function () {

    "use strict";

    //------------------------------------------------------------------------
    //						PRELOADER SCRIPT
    //------------------------------------------------------------------------
    $('#preloader').delay(400).fadeOut('slow'); // will fade out the back-DIV that covers the website.
    $('#preloader .loading-data').fadeOut(); // will first fade out the loading animation


})



