	/* ==========================
	   PRE-LOADER
	=============================*/
	
	$(window).load(function() {
		"use strict";
		// will fade loading animation
		$("#object").delay(600).fadeOut(300);
		// will fade loading background					
		$("#loading").delay(1000).fadeOut(500);
	})            

