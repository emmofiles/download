/*
 * POM - Creative Coming Soon Template
 * Build Date: June 2015
 * Author: Madeon08
 * Copyright (C) 2015 Madeon08
 * This is a premium product available exclusively here : http://themeforest.net/user/Madeon08/portfolio
 */

$(window).load(function() {

    /*
    * Loading
    */
    $('.loading-part').fadeOut();

});