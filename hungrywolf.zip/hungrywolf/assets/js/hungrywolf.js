$(document).ready(function(){
  $('#oh').fadeIn(500,function(){
    $('#no').fadeIn(500);
  });
});
